#include "../AffineGradientSearchX86.h"
